struct paramInfo {
	unsigned int a, b;
};
