struct sysStore {
	char bbmanufacturer[DATA_STRING_SIZE];
	char bbproduct[DATA_STRING_SIZE];
	char bbversion[DATA_STRING_SIZE];
	char sysfamily[DATA_STRING_SIZE];
	char sysmanufacturer[DATA_STRING_SIZE];
	char sysproduct[DATA_STRING_SIZE];
	char sysversion[DATA_STRING_SIZE];
};
