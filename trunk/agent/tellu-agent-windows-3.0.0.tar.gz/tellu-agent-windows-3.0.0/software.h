struct softwareStore {
	char name[DATA_STRING_SIZE];
	char version[DATA_STRING_SIZE];
	char size[DATA_STRING_SIZE];
	char url[DATA_STRING_SIZE];
};
