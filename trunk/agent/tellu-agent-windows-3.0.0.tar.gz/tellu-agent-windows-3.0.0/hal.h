struct halStore {
	char category[DATA_STRING_SIZE];
	char product[DATA_STRING_SIZE];
	char subsystem[DATA_STRING_SIZE];
	char capabilities[DATA_STRING_SIZE];
	char vendor[DATA_STRING_SIZE];
	char opt[DATA_STRING_SIZE];
};
