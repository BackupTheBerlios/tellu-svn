#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

#include "declarations.h"
#include "defines.h"



char *termNull(struct paramInfo * pi) {
	return(NULL);
}
