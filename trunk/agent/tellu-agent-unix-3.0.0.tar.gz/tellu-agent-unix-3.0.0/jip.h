int jipInput, jipOutput;
int jipBitCount;
int *jipCoded;
unsigned int *jipPrefix;
unsigned char *jipAppend;

int jipFind(int, unsigned int);
void jipOut(unsigned char *, unsigned int);
