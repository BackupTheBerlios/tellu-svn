struct loadStore {
	char load1[DATA_STRING_SIZE];
	char load2[DATA_STRING_SIZE];
	char load3[DATA_STRING_SIZE];
	char uptime1[DATA_STRING_SIZE];
	char uptime2[DATA_STRING_SIZE];
};
