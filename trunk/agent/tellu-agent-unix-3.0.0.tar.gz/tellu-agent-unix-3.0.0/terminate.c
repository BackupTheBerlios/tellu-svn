#include <stdio.h>
#include <stdlib.h>

#include "declarations.h"



char *termNull(struct paramInfo * pi) {
	return(NULL);
}
