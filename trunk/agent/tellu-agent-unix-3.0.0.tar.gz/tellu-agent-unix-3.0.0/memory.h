long long memGetThis(char *);
char *memParseArg(char *);
