char *netGetInterfaceList(void);
void netFreeInterfaceList(char *);
