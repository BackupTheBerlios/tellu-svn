int jipIn(unsigned char *, struct threadCompressInfo *);
unsigned char *jipDecode(unsigned char *, unsigned int, struct threadCompressInfo *);
