struct mainInfo mainMainInfo, *pMainMainInfo;

struct threadInfo mainThreadInfo, *pMainThreadInfo;
struct threadInfo threadPool[THREAD_TELMOND];
