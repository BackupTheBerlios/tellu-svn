void historyClose(Widget, XtPointer, XtPointer);
void historyExpose(Widget, XtPointer, XtPointer);
void historyMenuDate(Widget, XtPointer, XtPointer);
void historyUpdate(Widget, XtPointer, XtPointer);
void historyUpdateClear(Widget, XtPointer, XtPointer);
void historyUpdateInit(Widget, XtPointer, XtPointer);
unsigned long historyGetColor(char *);
