#include <stdio.h>
#include <stdlib.h>

#include "declarations.h"
#include "defines.h"



char *termNull(struct mainInfo * mi) {
	return(NULL);
}
