void exportCancel(Widget, XtPointer, XtPointer);
void exportOk(Widget, XtPointer, XtPointer);
