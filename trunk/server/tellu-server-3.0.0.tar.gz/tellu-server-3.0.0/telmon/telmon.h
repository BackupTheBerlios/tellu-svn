struct mainInfo mainMainInfo, *pMainMainInfo;
