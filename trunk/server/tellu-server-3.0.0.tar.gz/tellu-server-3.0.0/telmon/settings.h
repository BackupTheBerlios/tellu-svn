void settingsClose(Widget, XtPointer, XtPointer);
void settingsToggle(Widget, XtPointer, XtPointer);
